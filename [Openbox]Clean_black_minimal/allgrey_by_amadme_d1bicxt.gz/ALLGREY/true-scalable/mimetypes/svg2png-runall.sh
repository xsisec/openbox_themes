#!/bin/bash

#/bin/sh svg2png-18.sh
#/bin/sh svg2png-22.sh
#/bin/sh svg2png-24.sh
#/bin/sh svg2png-32.sh
#/bin/sh svg2png-48.sh
#/bin/sh svg2png-64.sh
/bin/sh svg2png-scalable.sh
